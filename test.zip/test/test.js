const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
	let totalRequest = 0;
	while(true) {
		console.log('Waiting Preseach 10 minute');
		console.log('Total Request: ' + totalRequest);
		
		await new Promise(resolve => setTimeout(resolve, 1000 * 60 * 10));
		await totalRequest++;
		
		await fs.readFile('data.txt', {encoding: 'utf-8'}, async (err,data) => {
			if (!err) {
				const dataList = data.split('\r\n');
				console.log("Token: " + dataList.length);
				let count = 1;
				for (const token of dataList) {
					await demo(token, count);
					count++;
				}
			} else {
				console.log(err);
			}
		});
		
	}
})();

async function demo(token, count) {
	console.log("Token: " + count + " [" + token.substring(token.length - 50, token.length) + "]");
	
	const browser = await puppeteer.launch({ 
		headless: true
	});
	
	/*
	const browser = await puppeteer.launch({ 
		headless: true,
		ignoreDefaultArgs: ["--disable-extensions","--enable-automation"],
		args: [
			'--load-extension=',
			'--disable-extensions-except='
		]
	});
	*/
	const page = await browser.newPage();
	const timeout = 10000;
	page.setDefaultTimeout(timeout);

	for (var i = 0; i < 1; i++) {
		console.log('Start Preseach: ' + i);
		try { 
			await new Promise(resolve => setTimeout(resolve, 10000));
			async function waitForSelectors(selectors, frame, timeout) {
			  for (const selector of selectors) {
				try {
				  return await waitForSelector(selector, frame, timeout);
				} catch (err) {
				  console.error(err);
				}
			  }
			  throw new Error('Could not find element for selectors: ' + JSON.stringify(selectors));
			}

			async function waitForSelector(selector, frame, timeout) {
			  if (selector instanceof Array) {
				let element = null;
				for (const part of selector) {
				  if (!element) {
					element = await frame.waitForSelector(part, { timeout });
				  } else {
					element = await element.$(part);
				  }
				  if (!element) {
					throw new Error('Could not find element: ' + part);
				  }
				  element = (await element.evaluateHandle(el => el.shadowRoot ? el.shadowRoot : el)).asElement();
				}
				if (!element) {
				  throw new Error('Could not find element: ' + selector.join('|'));
				}
				return element;
			  }
			  const element = await frame.waitForSelector(selector, { timeout });
			  if (!element) {
				throw new Error('Could not find element: ' + selector);
			  }
			  return element;
			}

			async function waitForElement(step, frame, timeout) {
			  const count = step.count || 1;
			  const operator = step.operator || '>=';
			  const comp = {
				'==': (a, b) => a === b,
				'>=': (a, b) => a >= b,
				'<=': (a, b) => a <= b,
			  };
			  const compFn = comp[operator];
			  await waitForFunction(async () => {
				const elements = await querySelectorsAll(step.selectors, frame);
				return compFn(elements.length, count);
			  }, timeout);
			}

			async function querySelectorsAll(selectors, frame) {
			  for (const selector of selectors) {
				const result = await querySelectorAll(selector, frame);
				if (result.length) {
				  return result;
				}
			  }
			  return [];
			}

			async function querySelectorAll(selector, frame) {
			  if (selector instanceof Array) {
				let elements = [];
				let i = 0;
				for (const part of selector) {
				  if (i === 0) {
					elements = await frame.$$(part);
				  } else {
					const tmpElements = elements;
					elements = [];
					for (const el of tmpElements) {
					  elements.push(...(await el.$$(part)));
					}
				  }
				  if (elements.length === 0) {
					return [];
				  }
				  const tmpElements = [];
				  for (const el of elements) {
					const newEl = (await el.evaluateHandle(el => el.shadowRoot ? el.shadowRoot : el)).asElement();
					if (newEl) {
					  tmpElements.push(newEl);
					}
				  }
				  elements = tmpElements;
				  i++;
				}
				return elements;
			  }
			  const element = await frame.$$(selector);
			  if (!element) {
				throw new Error('Could not find element: ' + selector);
			  }
			  return element;
			}

			async function waitForFunction(fn, timeout) {
			  let isActive = true;
			  setTimeout(() => {
				isActive = false;
			  }, timeout);
			  while (isActive) {
				const result = await fn();
				if (result) {
				  return;
				}
				await new Promise(resolve => setTimeout(resolve, 100));
			  }
			  throw new Error('Timed out');
			}
			{
				const targetPage = page;
				await targetPage.setViewport({"width":1349,"height":169})
			}
			{
				const targetPage = page;
				const promises = [];
				promises.push(targetPage.waitForNavigation());
				const response = await targetPage.goto('https://engine.presearch.org/search?q=hay an vn');
				const cookies = [{
				  'name': 'token',
				  'value': token
				}];

				await targetPage.setCookie(...cookies);
				
				console.log(response.status());
				
				if (response.status() != 200) {
					return;
				}
				
				await Promise.all(promises);
			}
			{
				const targetPage = page;
				const element = await waitForSelectors([["body > div > div.relative.flex.bg-background-light200.dark\\:bg-background-dark500.h-full.md\\:min-h-screen > div.flex.flex-col.flex-auto.w-full.h-full.md\\:min-h-screen > div:nth-child(1) > dic > div.flex.flex-col.w-full.pr-2.bg-background-light100.dark\\:bg-background-dark500.sm\\:pr-0 > div.flex.items-center.md\\:max-w-xl.lg\\:max-w-2xl.ml-1.relative > div > form > div > div > svg > path"]], targetPage, timeout);
				await element.click({ offset: { x: 3, y: 4.9997406005859375} });
			}
			{
				const targetPage = page;
				const element = await waitForSelectors([["aria/What are you looking for today?"],["body > div > div.relative.flex.bg-background-light200.dark\\:bg-background-dark500.h-full.md\\:min-h-screen > div.flex.flex-col.flex-auto.w-full.h-full.md\\:min-h-screen > div:nth-child(1) > dic > div.flex.flex-col.w-full.pr-2.bg-background-light100.dark\\:bg-background-dark500.sm\\:pr-0 > div.flex.items-center.md\\:max-w-xl.lg\\:max-w-2xl.ml-1.relative > div > form > div > input"]], targetPage, timeout);
				await element.click({ offset: { x: 469, y: 35} });
			}
			{
				var data = 'thuoc do online ' + new Date().getTime();
				const targetPage = page;
				const element = await waitForSelectors([["aria/What are you looking for today?"],["body > div > div.relative.flex.bg-background-light200.dark\\:bg-background-dark500.h-full.md\\:min-h-screen > div.flex.flex-col.flex-auto.w-full.h-full.md\\:min-h-screen > div:nth-child(1) > dic > div.flex.flex-col.w-full.pr-2.bg-background-light100.dark\\:bg-background-dark500.sm\\:pr-0 > div.flex.items-center.md\\:max-w-xl.lg\\:max-w-2xl.ml-1.relative > div > form > div > input"]], targetPage, timeout);
				const type = await element.evaluate(el => el.type);
				if (["textarea","select-one","text","url","tel","search","password","number","email"].includes(type)) {
				  await element.type(data);
				} else {
				  await element.focus();
				  await element.evaluate((el, value) => {
					el.value = value;
					el.dispatchEvent(new Event('input', { bubbles: true }));
					el.dispatchEvent(new Event('change', { bubbles: true }));
				  }, data);
				}
			}
			{
				const targetPage = page;
				const promises = [];
				promises.push(targetPage.waitForNavigation());
				await targetPage.keyboard.down("Enter");
				await Promise.all(promises);
			}
			{
				const targetPage = page;
				await targetPage.keyboard.up("Enter");
			}
			{
				const targetPage = page;
				const cookies = await targetPage.cookies();
				//console.log(cookies);
			}
			
		} catch(err) { console.log(err) }
	}
	await browser.close();
}